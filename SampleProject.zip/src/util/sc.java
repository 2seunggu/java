package util;

import java.util.Scanner;

public class sc {
	private static Scanner s = new Scanner(System.in);
	
	public static String nextLine(){
		return s.nextLine();
	}
	
	public static int nextInt(){
		return Integer.parseInt(s.nextLine());
	}
}
