package util;

public class View {

	public static final int home = 0;
	public static final int login = 1;
	public static final int join = 2;
	public static final int Board_List = 3;
}
