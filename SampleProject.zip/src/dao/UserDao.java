package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import util.Jdbcutil;

public class UserDao {
	private UserDao(){}
	private static UserDao instance;
	public static UserDao getInstence(){
		if(instance == null){
			instance = new UserDao();
		}
		return instance;
	}
	private Jdbcutil jdbc = Jdbcutil.getInstance();
	
	public int insertUser(Map<String, Object> param){
		String sql = "INSERT INTO CLIENT VALUES (?,?,?,0)";
		
		List<Object> p = new ArrayList<>();
		p.add(param.get("USER_ID"));
		p.add(param.get("PASSWORD"));
		p.add(param.get("USER_NAME"));
		
		return jdbc.update(sql, p);
	}
	public Map<String, Object> selectUser(String userId, String password){
		String sql = "SELECT USER_ID, PASSWORD, USER_NAME FROM CLIENT WHERE USER_ID = ? AND PASSWORD = ?";
			List<Object> param = new ArrayList<>();
			param.add(userId);
			param.add(password);
			
			return jdbc.selectOne(sql,param);
	}
}
