package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import util.Jdbcutil;

public class BoardDao {
	private BoardDao(){}
	private static BoardDao instance;
	public static BoardDao getInstence(){
		if(instance == null){
			instance = new BoardDao();
		}
		return instance;
	}
	
	private Jdbcutil jdbc = Jdbcutil.getInstance();
	
	public List<Map<String, Object>> selectBoardList(){
		String sql = "SELECT A.BOARD_NO, A.TITLE, A.CONTENT, B.USER_NAME, A.REG_DATE"
				+ " FROM CLIENT_BOARD A"
				+ " LEFT OUTER JOIN CLIENT B"
				+ " ON A.USER_ID = B.USER_ID"
				+ " ORDER BY A.BOARD_NO DESC" ;
		
		return jdbc.selectList(sql);
				
	}
	
}
