package service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import util.View;
import util.Jdbcutil;
import util.sc;
import controller.Controller;
import dao.BoardDao;

public class BoardService {
	private BoardService() {
	}

	private static BoardService instance;
	Jdbcutil jdbc = Jdbcutil.getInstance();

	public static BoardService getInstence() {
		if (instance == null) {
			instance = new BoardService();
		}
		return instance;
	}

	private BoardDao boardDao = BoardDao.getInstence();

	public int boardList() {
		List<Map<String, Object>> boardList = boardDao.selectBoardList();

		System.out.println("========================================");
		System.out.println("번호\t 제목\t 작성자\t 작성일");
		System.out.println("========================================");
		for (Map<String, Object> board : boardList) {
			System.out.println(board.get("BOARD_NO") + "\t"
					+ board.get("TITLE") + "\t" + board.get("USER_NAME") + "\t"
					+ board.get("REG_DATE"));
		}
		System.out.println("========================================");
		System.out.println("1.조회\t 2.등록\t 0.로그아웃");
		System.out.print("번호를 입력해 주세요 : ");
		int input = sc.nextInt();
		switch (input) {
		case 1:
			System.out.println("조회할 번호를 입력해 주세요");
			int input1 = sc.nextInt();
			String sql = "SELECT * FROM CLIENT_BOARD WHERE BOARD_NO = ?";
			ArrayList<Object> param1 = new ArrayList<>();
			param1.add(input1);

			List<Map<String, Object>> list = jdbc.selectList(sql, param1);

			for (int i = 0; i < list.size(); i++) {
				Map<String, Object> map = list.get(i);
				System.out.println("========================================");
				System.out.println("번호\t 제목\t 작성자\t 작성일");
				System.out.println("========================================");
				System.out.println(map.get("BOARD_NO") + "\t"
						+ map.get("TITLE") + "\t" + map.get("USER_NAME") + "\t"
						+ map.get("REG_DATE"));
				System.out.println("========================================");
				System.out.println(map.get("CONTENT"));

				System.out.println();
				System.out.println("1.수정\t2.삭제\t0.목록");
				int input2 = sc.nextInt();
				switch (input2) {
				case 1:
					System.out.println("1.제목수정\t2.내용수정\t0.뒤로가기");
					int input3 = sc.nextInt();
					switch (input3) {
					case 1:
						String UpdateTitle = "UPDATE CLIENT_BOARD SET title = ? WHERE BOARD_NO = ?";
						System.out.println("변경하실 제목을 입력해주세요");
						String title = sc.nextLine();
						ArrayList<Object> param = new ArrayList<>();
						param.add(title);
						param.add(input1);
						int result = jdbc.update(UpdateTitle, param);
						if (result == 1) {
							System.out.println("변경이 완료 되었습니다.");
						}
						break;
					case 2:
						String UpdateContent = "UPDATE CLIENT_BOARD SET title = ? WHERE BOARD_NO = ?";
						System.out.println("변경하실 내용을 입력해주세요");
						String content = sc.nextLine();
						ArrayList<Object> param2 = new ArrayList<>();
						param2.add(content);
						param2.add(input1);
						int result1 = jdbc.update(UpdateContent, param2);
						if (result1 == 1) {
							System.out.println("변경이 완료 되었습니다.");
						}
						break;
					case 0:
						break;
					}
				case 2:
					String sqlDelete = "DELETE FROM CLIENT_BOARD WHERE BOARD_NO = ?";

					ArrayList<Object> param = new ArrayList<>();
					param.add(input1);
					int result = jdbc.update(sqlDelete, param);
					if (result > 0) {
						System.out.println("삭제가 완료 되었습니다.");
					}
				}

			}
			break;
		case 2:
			String InsertBoard = "INSERT INTO CLIENT_BOARD VALUES ((SELECT NVL(MAX(BOARD_NO), 0) + 1 FROM CLIENT_BOARD),?,?,?,SYSDATE)";
			System.out.println("제목을 입력해 주세요");
			String TITLE = sc.nextLine();
			System.out.println("내용을 입력해 주세요");
			String CONTENT = sc.nextLine();

			ArrayList<Object> param = new ArrayList<>();
			param.add(TITLE);
			param.add(CONTENT);
			param.add(Controller.LoginUser.get("USER_ID"));

			int result = jdbc.update(InsertBoard, param);
			if (result == 1) {
				System.out.println("게시물 등록이 완료되었습니다.");
			}
		case 0:
			Controller.LoginUser = null;
			return View.Board_List;
		}
		return View.Board_List;

	}
}
