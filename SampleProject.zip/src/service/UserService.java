package service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import util.View;
import util.Jdbcutil;
import util.sc;
import controller.Controller;
import dao.UserDao;

public class UserService {

		//싱글톤 패턴
		private UserService(){}
		private static UserService instance;
		public static UserService getInstence(){
			if(instance == null){
				instance = new UserService();
			}
			return instance;
		}
		
		private UserDao userdao = UserDao.getInstence();
		private Jdbcutil jdbc = Jdbcutil.getInstance();
		//회원가입
		public int join(){
			System.out.println("========== 회원 가입 ==========");
			System.out.print("아이디 :");
			String userId = sc.nextLine();
			Jdbcutil jdbc = Jdbcutil.getInstance();
			String sql = "SELECT * FROM CLIENT WHERE USER_ID = ?";
			ArrayList<Object> param1 = new ArrayList<>();
			param1.add(userId);
			List<Map<String, Object>> list = jdbc.selectList(sql, param1);
			
			for(int i=0; i<list.size(); i++){
				Map<String, Object> row = list.get(i);
				for(String key : row.keySet()){
			if(row.get(key) == null) {
			}else if(row.get(key) != null){
				System.out.println("중복된 아이디 입니다.");
				return 2;
			}
			}
			}
			String regex = "[a-z0-9]{5,20}";
			Pattern p = Pattern.compile(regex);
			Matcher m = p.matcher(userId);
			if(m.matches() == false) {
			System.out.println("5~20자의 영문 소문자와 숫자만 사용가능합니다.");
			return 2;
			} else { 
				System.out.println("ok");
			}
			System.out.print("비밀번호 :");
			String PassWord = sc.nextLine();
			String regex1 = "[a-z0-9]{5,20}";
			Pattern p1 = Pattern.compile(regex1);
			Matcher m1 = p1.matcher(PassWord);
			if(m1.matches() == false) {
			System.out.println("5~20자의 영문 소문자와 숫자만 사용가능합니다.");
			return 2;
			} else { 
				System.out.println("ok");
				
			}
			System.out.print("비밀번호 재입력:");
			String RePassWord = sc.nextLine();
			String regex3 = "[a-z0-9]{5,20}";
			Pattern p3 = Pattern.compile(regex3);
			Matcher m3 = p3.matcher(RePassWord);
			if(m1.matches() == false) {
				System.out.println("5~20자의 영문 소문자와 숫자만 사용가능합니다.");
				return 2;
			} else if(PassWord.equals(RePassWord)){
				System.out.println("비밀번호가 일치합니다.");
			} else{
				System.out.println("비밀번호가 일치하지 않습니다.");
				return 2;
			}
			System.out.print("이름 :");
			String UserName = sc.nextLine();
			String regex2 = "[a-z0-9]{2,8}";
			Pattern p2 = Pattern.compile(regex2);
			Matcher m2 = p2.matcher(UserName);
			if(m1.matches() == false) {
			System.out.println("2~8글자의 영문 소문자와 숫자만 사용가능합니다.");
			return 2;
			} else { 
				System.out.println("ok");
			}

		Map<String, Object> param = new HashMap<>();
		param.put("USER_ID", userId);
		param.put("PASSWORD", PassWord);
		param.put("USER_NAME", UserName);
		
		int result = userdao.insertUser(param);
		
		if(0<result) {
			System.out.println("회원가입 성공");
		}else{
			System.out.println("회원가입 실패");
		}
		return View.home;
	
	}
	//로그인
	public int login(){
		System.out.println("========== 로그인 ==========");
		System.out.print("아이디 : ");
		String User_Id = sc.nextLine();
		System.out.print("비밀번호 : ");
		String PassWord = sc.nextLine();
		
		//둘다 일치하는사람 찾기
		Map<String, Object> user = userdao.selectUser(User_Id, PassWord);
		
		if(user == null){
			System.out.println("아이디 혹은 비밀번호를 잘못 입력했습니다.");
		} else{
			System.out.println("로그인 성공");
			
			Controller.LoginUser = user; // 로그인 정보를 controller에 있는 loginuser에 저장
			
			return View.Board_List;	// 모든정보를 boardlist에 전달
		}
	
		
		return View.login;
	}
}